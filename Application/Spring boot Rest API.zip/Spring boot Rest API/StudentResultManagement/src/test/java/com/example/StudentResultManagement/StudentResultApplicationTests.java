package com.example.StudentResultManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentResultApplicationTests {

	@Test
	void contextLoads() {
	}

}
