package com.example.login.data;

public class StudentRepo {
}
