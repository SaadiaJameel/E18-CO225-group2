//package com.example.login.UI;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.constraintlayout.utils.widget.ImageFilterButton;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ImageButton;
//
//import com.example.login.R;
//
//public class SemesterAllStudent extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_semester_all_student);
//
//
//        ImageButton settingsBtn = findViewById(R.id.settings);
//        settingsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                openSettingsMain();
//            }
//        });
//    }
//
//    public void openSettingsMain(){
//        Intent intent = new Intent(this, SettingsMain.class);
//        startActivity(intent);
//    }
//}

package com.example.login.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.login.R;
import com.example.login.model.SemesterModel;
import com.example.login.net.addSemService;
import com.example.login.retrofit.RetroFitService;

import java.util.List;
import java.util.*;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SemesterAllStudent extends AppCompatActivity {

    Button newbtn;
    int length;
    int semNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester_all_student);

        int field = MainActivity.s.getFieldgroup();

        //use retrofit service
        RetroFitService retrofit = new RetroFitService();

        //create instance of employee api object
        addSemService semapi =retrofit.getRetrofit().create(addSemService.class);

        ImageButton refresh = findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                semapi.getSemesters(field)
                        .enqueue(new Callback<List<SemesterModel>>() {
                            @Override
                            public void onResponse(Call<List<SemesterModel>> call, Response<List<SemesterModel>> response) {

                                List<SemesterModel> myheroList = response.body();
                                length = myheroList.size();

                                for (int i = 0 ;  i < length ;  i++) {
                                    semNumber = myheroList.get(i).getSemnumber();
                                    String semNumberStr = "Semester " + semNumber;
                                    refreshPage(semNumberStr);
                                }

                            }

                            @Override
                            public void onFailure(Call<List<SemesterModel>> call, Throwable t) {

                            }
                        });
            }
        });

        ImageButton settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsMain();
            }
        });
    }

    public void refreshPage(String text){
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootlayout);
        newbtn = new Button(this);
        newbtn.setId(semNumber);
        newbtn.setText(text);
        layout.addView(newbtn);
        newbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCoursePage();
            }
        });
    }

    public void openSettingsMain(){
        Intent intent = new Intent(this, SettingsMain.class);
        startActivity(intent);
    }

    public void openCoursePage(){
        Intent intent = new Intent(this, coursePageStudent.class);
        startActivity(intent);
    }
}